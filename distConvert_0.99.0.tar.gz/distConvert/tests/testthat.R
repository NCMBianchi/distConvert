library(testthat)
test_check("distConvert")
